The application "DriverApp" is developed using Android Technology

Features:
A driver can register into the "DriverApp" application with name, email, password, contact no, image, license image, and plate no.
Customer or user can register into the application with name, email, password, and contact no. 
If the user and driver have already registered accounts, then both can directly login into the application with email and password. 
Users can search for available drivers.
Users can book a driver successfully from available location. 
Admin can check user profile and payment status.


Permission:
Camera
File Manager
Device Orientation

Database:
Google Firebase

Version
DriverApp 1.0

